using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

[System.Serializable]
public class WaypointRoute 
{
    public string routeName = "Nova Rota";
    public Transform[] waypoints;
    public bool isLooping = true;
    public Color routeColor = Color.white;
}

public class AutopilotSystem : MonoBehaviour
{
    [Header("Rotas e Waypoints")]
    public List<WaypointRoute> routes = new List<WaypointRoute>();
    public int currentRouteIndex = 0;
    public int currentWaypointIndex = 0;
    private Transform currentWaypoint;
    private Transform nextWaypoint;
    
    [Header("Configurações de Navegação")]
    public float waypointRadius = 5.0f;     // Raio para considerar waypoint alcançado
    public float lookAheadDistance = 10.0f;  // Distância para olhar adiante da curva
    public float maxSpeed = 50.0f;           // Velocidade máxima em km/h
    public float corneringSpeed = 30.0f;     // Velocidade reduzida para curvas
    public float brakeDistance = 20.0f;      // Distância para começar a frear
    public float accelerationFactor = 1.0f;  // Fator de aceleração
    public float steeringFactor = 1.0f;      // Fator de direção
    public float obstacleDetectionDistance = 20.0f; // Distância para detectar obstáculos
    
    [Header("Componentes")]
    private CarInputController carController;
    private Rigidbody rb;
    
    [Header("Estado do Piloto Automático")]
    public bool autopilotEnabled = false;
    public KeyCode toggleAutopilotKey = KeyCode.P;
    public bool showDebugVisuals = true;
    
    [Header("UI")]
    public Text autopilotStatusText;
    public Image autopilotStatusIcon;
    public Color activeColor = Color.green;
    public Color inactiveColor = Color.red;
    
    [Header("Sensors")]
    public Transform frontSensorPosition;
    public LayerMask obstacleLayerMask;
    
    // Variáveis privadas
    private float targetSpeed = 0f;
    private float currentThrottle = 0f;
    private float currentBrake = 0f;
    private float currentSteer = 0f;
    private bool obstacleDetected = false;
    private Transform lastWaypointHit;
    
    private void Start()
    {
        carController = GetComponent<CarInputController>();
        rb = GetComponent<Rigidbody>();
        
        if (carController == null)
        {
            Debug.LogError("AutopilotSystem requer um componente CarInputController no mesmo GameObject.");
            enabled = false;
            return;
        }
        
        if (rb == null)
        {
            Debug.LogError("AutopilotSystem requer um componente Rigidbody no mesmo GameObject.");
            enabled = false;
            return;
        }
        
        // Se não houver sensor frontal definido, criar um
        if (frontSensorPosition == null)
        {
            GameObject sensorObj = new GameObject("FrontSensor");
            sensorObj.transform.parent = transform;
            sensorObj.transform.localPosition = new Vector3(0, 0.5f, 2.0f);
            frontSensorPosition = sensorObj.transform;
        }
        
        UpdateWaypointReferences();
        UpdateAutopilotUI();
    }
    
    private void Update()
    {
        // Alternar piloto automático com tecla
        if (Input.GetKeyDown(toggleAutopilotKey))
        {
            autopilotEnabled = !autopilotEnabled;
            UpdateAutopilotUI();
            
            // Resetar controles ao desligar
            if (!autopilotEnabled)
            {
                currentThrottle = 0f;
                currentBrake = 0f;
                currentSteer = 0f;
            }
        }
        
        // Trocar para próxima rota com Tab
        if (Input.GetKeyDown(KeyCode.Tab) && routes.Count > 1)
        {
            currentRouteIndex = (currentRouteIndex + 1) % routes.Count;
            currentWaypointIndex = 0;
            UpdateWaypointReferences();
        }
    }
    
    private void FixedUpdate()
    {
        if (!autopilotEnabled) return;
        
        // Atualizar referências de waypoints se necessário
        if (currentWaypoint == null)
        {
            UpdateWaypointReferences();
            if (currentWaypoint == null) return; // Sem waypoints disponíveis
        }
        
        // Verificar se chegou ao waypoint atual
        float distanceToWaypoint = Vector3.Distance(transform.position, currentWaypoint.position);
        if (distanceToWaypoint < waypointRadius)
        {
            // Avançar para o próximo waypoint
            currentWaypointIndex++;
            
            // Verificar se chegou ao fim da rota
            WaypointRoute currentRoute = routes[currentRouteIndex];
            if (currentWaypointIndex >= currentRoute.waypoints.Length)
            {
                if (currentRoute.isLooping)
                {
                    currentWaypointIndex = 0;
                }
                else
                {
                    // Fim da rota não-cíclica, desativar piloto automático
                    autopilotEnabled = false;
                    UpdateAutopilotUI();
                    return;
                }
            }
            
            UpdateWaypointReferences();
        }
        
        // Verificar obstáculos à frente
        DetectObstacles();
        
        // Calcular direção para o waypoint
        CalculateNavigation();
        
        if (carController != null)
            {
                carController.SetAutopilotControls(currentThrottle, currentBrake, currentSteer);
            }
    }
    
    private void UpdateWaypointReferences()
    {
        if (routes.Count == 0 || currentRouteIndex >= routes.Count) return;
        
        WaypointRoute currentRoute = routes[currentRouteIndex];
        if (currentRoute.waypoints == null || currentRoute.waypoints.Length == 0) return;
        
        // Garantir que o índice esteja dentro dos limites
        currentWaypointIndex = Mathf.Clamp(currentWaypointIndex, 0, currentRoute.waypoints.Length - 1);
        
        // Atualizar waypoint atual
        currentWaypoint = currentRoute.waypoints[currentWaypointIndex];
        
        // Atualizar próximo waypoint para planejamento de curvas
        int nextIndex = (currentWaypointIndex + 1) % currentRoute.waypoints.Length;
        nextWaypoint = currentRoute.waypoints[nextIndex];
        
        // Se a rota não for cíclica e estiver no último ponto, o próximo é o mesmo
        if (!currentRoute.isLooping && currentWaypointIndex == currentRoute.waypoints.Length - 1)
        {
            nextWaypoint = currentWaypoint;
        }
    }
    
    private void CalculateNavigation()
    {
        if (currentWaypoint == null) return;
        
        // Calcular vetor para o waypoint atual
        Vector3 directionToWaypoint = currentWaypoint.position - transform.position;
        directionToWaypoint.y = 0; // Ignorar diferença de altura
        
        // Calcular ângulo relativo
        float relativeAngle = Vector3.SignedAngle(transform.forward, directionToWaypoint, Vector3.up);
        
        // Normalizar para range de -1 a 1 para direção
        currentSteer = Mathf.Clamp(relativeAngle / 45f, -1f, 1f) * steeringFactor;
        
        // Calcular distância até o waypoint
        float distanceToWaypoint = directionToWaypoint.magnitude;
        
        // Calcular velocidade desejada baseada na curvatura da trajetória
        float angleToNextWaypoint = 0f;
        if (nextWaypoint != null && nextWaypoint != currentWaypoint)
        {
            Vector3 currentToNext = nextWaypoint.position - currentWaypoint.position;
            angleToNextWaypoint = Vector3.Angle(directionToWaypoint, currentToNext);
        }
        
        // Determinar velocidade alvo
        if (obstacleDetected)
        {
            targetSpeed = 0f; // Parar se houver obstáculo
        }
        else
        {
            // Velocidade baseada na curva (quanto maior o ângulo, menor a velocidade)
            float curveSpeedFactor = Mathf.Clamp01(1f - (angleToNextWaypoint / 180f));
            float desiredSpeed = Mathf.Lerp(corneringSpeed, maxSpeed, curveSpeedFactor);
            
            // Reduzir velocidade se estiver se aproximando do waypoint
            float approachFactor = Mathf.Clamp01(distanceToWaypoint / brakeDistance);
            if (distanceToWaypoint < brakeDistance)
            {
                desiredSpeed *= approachFactor;
            }
            
            // Suavizar mudanças de velocidade alvo
            targetSpeed = Mathf.Lerp(targetSpeed, desiredSpeed, Time.fixedDeltaTime * 2f);
        }
        
        // Converter velocidade em throttle/brake
        float currentSpeed = rb.velocity.magnitude * 3.6f; // em km/h
        
        if (currentSpeed < targetSpeed)
        {
            // Acelerar
            currentThrottle = Mathf.Clamp01((targetSpeed - currentSpeed) / 20f) * accelerationFactor;
            currentBrake = 0f;
        }
        else
        {
            // Frear
            currentThrottle = 0f;
            currentBrake = Mathf.Clamp01((currentSpeed - targetSpeed) / 20f);
        }
        
        // Intensificar frenagem em ângulos acentuados
        if (Mathf.Abs(relativeAngle) > 45f)
        {
            currentThrottle *= Mathf.Clamp01(1f - (Mathf.Abs(relativeAngle) - 45f) / 45f);
            currentBrake = Mathf.Max(currentBrake, (Mathf.Abs(relativeAngle) - 45f) / 45f * 0.5f);
        }
    }
    
    private void DetectObstacles()
    {
        obstacleDetected = false;
        
        if (frontSensorPosition == null) return;
        
        // Lançar raio à frente do veículo
        RaycastHit hit;
        if (Physics.Raycast(frontSensorPosition.position, frontSensorPosition.forward, 
                           out hit, obstacleDetectionDistance, obstacleLayerMask))
        {
            obstacleDetected = true;
            
            // Ignorar se o hit for um waypoint (se eles tiverem colliders)
            if (hit.transform == currentWaypoint || hit.transform == nextWaypoint)
            {
                obstacleDetected = false;
            }
            
            // Evitar detectar repetidamente o mesmo waypoint
            if (hit.transform == lastWaypointHit)
            {
                obstacleDetected = false;
            }
            else if (hit.transform == currentWaypoint || hit.transform == nextWaypoint)
            {
                lastWaypointHit = hit.transform;
            }
            
            if (obstacleDetected && showDebugVisuals)
            {
                Debug.DrawLine(frontSensorPosition.position, hit.point, Color.red);
                Debug.Log("Obstáculo detectado: " + hit.transform.name);
            }
        }
        
        if (showDebugVisuals && !obstacleDetected)
        {
            Debug.DrawRay(frontSensorPosition.position, 
                         frontSensorPosition.forward * obstacleDetectionDistance, Color.green);
        }
    }
    
    private void UpdateAutopilotUI()
    {
        if (autopilotStatusText != null)
        {
            autopilotStatusText.text = autopilotEnabled ? "Piloto Automático: ATIVO" : "Piloto Automático: DESATIVADO";
        }
        
        if (autopilotStatusIcon != null)
        {
            autopilotStatusIcon.color = autopilotEnabled ? activeColor : inactiveColor;
        }
    }
    
    public void AddWaypointToCurrentRoute(Vector3 position)
    {
        if (routes.Count == 0)
        {
            // Criar nova rota se não houver nenhuma
            WaypointRoute newRoute = new WaypointRoute();
            routes.Add(newRoute);
            currentRouteIndex = 0;
        }
        
        WaypointRoute currentRoute = routes[currentRouteIndex];
        
        // Criar objeto para o waypoint
        GameObject waypointObj = new GameObject("Waypoint_" + 
                                               (currentRoute.waypoints != null ? currentRoute.waypoints.Length : 0));
        waypointObj.transform.position = position;
        
        // Adicionar ao array de waypoints
        if (currentRoute.waypoints == null)
        {
            currentRoute.waypoints = new Transform[1];
            currentRoute.waypoints[0] = waypointObj.transform;
        }
        else
        {
            // Redimensionar array
            System.Array.Resize(ref currentRoute.waypoints, currentRoute.waypoints.Length + 1);
            currentRoute.waypoints[currentRoute.waypoints.Length - 1] = waypointObj.transform;
        }
        
        // Atualizar referências
        UpdateWaypointReferences();
    }
    
    public void CreateNewRoute()
    {
        WaypointRoute newRoute = new WaypointRoute();
        newRoute.routeName = "Rota " + routes.Count;
        routes.Add(newRoute);
        currentRouteIndex = routes.Count - 1;
    }
    
    // Função para visualizar as rotas no Editor
    private void OnDrawGizmos()
    {
        if (!showDebugVisuals) return;
        
        // Desenhar todas as rotas
        for (int r = 0; r < routes.Count; r++)
        {
            WaypointRoute route = routes[r];
            if (route.waypoints == null || route.waypoints.Length == 0) continue;
            
            // Definir cor da rota
            Gizmos.color = route.routeColor;
            
            // Desenhar linha entre waypoints
            for (int i = 0; i < route.waypoints.Length; i++)
            {
                if (route.waypoints[i] == null) continue;
                
                // Destacar rota atual
                if (r == currentRouteIndex)
                {
                    // Destacar waypoint atual
                    if (i == currentWaypointIndex)
                    {
                        Gizmos.DrawSphere(route.waypoints[i].position, waypointRadius * 0.5f);
                    }
                    else
                    {
                        Gizmos.DrawSphere(route.waypoints[i].position, 1f);
                    }
                }
                else
                {
                    Gizmos.DrawSphere(route.waypoints[i].position, 0.5f);
                }
                
                // Desenhar linhas conectando os waypoints
                if (i + 1 < route.waypoints.Length && route.waypoints[i + 1] != null)
                {
                    Gizmos.DrawLine(route.waypoints[i].position, route.waypoints[i + 1].position);
                }
                else if (route.isLooping && route.waypoints[0] != null)
                {
                    // Conectar o último ao primeiro se for loop
                    Gizmos.DrawLine(route.waypoints[i].position, route.waypoints[0].position);
                }
            }
        }
        
        // Desenhar informações sobre o waypoint atual
        if (autopilotEnabled && currentWaypoint != null)
        {
            Gizmos.color = Color.yellow;
            Gizmos.DrawLine(transform.position, currentWaypoint.position);
            
            // Desenhar círculo de alcance do waypoint
            DrawWireDisc(currentWaypoint.position, Vector3.up, waypointRadius, 32);
        }
    }
    
    // Função auxiliar para desenhar disco no Gizmos
    private void DrawWireDisc(Vector3 position, Vector3 normal, float radius, int segments)
    {
        Vector3 from = Vector3.up;
        if (normal == from || normal == -from)
        {
            from = Vector3.forward;
        }
        
        Vector3 right = Vector3.Cross(normal, from).normalized * radius;
        Vector3 forward = Vector3.Cross(normal, right).normalized * radius;
        
        for (int i = 0; i < segments; i++)
        {
            float angle1 = (float)i / segments * 2 * Mathf.PI;
            float angle2 = (float)(i + 1) / segments * 2 * Mathf.PI;
            
            Vector3 pos1 = position + right * Mathf.Cos(angle1) + forward * Mathf.Sin(angle1);
            Vector3 pos2 = position + right * Mathf.Cos(angle2) + forward * Mathf.Sin(angle2);
            
            Gizmos.DrawLine(pos1, pos2);
        }
    }
}
