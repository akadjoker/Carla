
using UnityEngine;
using UnityEngine.UI;
#if UNITY_EDITOR
using UnityEditor;

[CustomEditor(typeof(AutopilotSystem))]
public class AutopilotSystemEditor : Editor
{
    private SerializedProperty routes;
    private SerializedProperty currentRouteIndex;
    private SerializedProperty waypointRadius;
    private SerializedProperty maxSpeed;
    private SerializedProperty corneringSpeed;
    private SerializedProperty showDebugVisuals;
    
    private void OnEnable()
    {
        routes = serializedObject.FindProperty("routes");
        currentRouteIndex = serializedObject.FindProperty("currentRouteIndex");
        waypointRadius = serializedObject.FindProperty("waypointRadius");
        maxSpeed = serializedObject.FindProperty("maxSpeed");
        corneringSpeed = serializedObject.FindProperty("corneringSpeed");
        showDebugVisuals = serializedObject.FindProperty("showDebugVisuals");
    }
    
    public override void OnInspectorGUI()
    {
        serializedObject.Update();
        
        AutopilotSystem autopilot = (AutopilotSystem)target;
        
        // Desenhar componentes padrão, agrupados por seções
        EditorGUILayout.LabelField("Rotas e Waypoints", EditorStyles.boldLabel);
        EditorGUILayout.PropertyField(routes);
        
        if (routes.arraySize > 0)
        {
            // Desenhar interface para selecionar rota atual
            EditorGUILayout.Space();
            EditorGUILayout.BeginHorizontal();
            EditorGUILayout.PropertyField(currentRouteIndex);
            
            // Manter o índice dentro dos limites
            if (currentRouteIndex.intValue >= routes.arraySize)
            {
                currentRouteIndex.intValue = routes.arraySize - 1;
            }
            
            if (currentRouteIndex.intValue < 0)
            {
                currentRouteIndex.intValue = 0;
            }
            
            // Botão para adicionar nova rota
            if (GUILayout.Button("Nova Rota", GUILayout.Width(100)))
            {
                autopilot.CreateNewRoute();
                serializedObject.Update();
            }
            
            EditorGUILayout.EndHorizontal();
            
            // Gerenciar waypoints da rota atual
            if (currentRouteIndex.intValue < routes.arraySize)
            {
                SerializedProperty currentRoute = routes.GetArrayElementAtIndex(currentRouteIndex.intValue);
                SerializedProperty routeName = currentRoute.FindPropertyRelative("routeName");
                SerializedProperty waypoints = currentRoute.FindPropertyRelative("waypoints");
                SerializedProperty isLooping = currentRoute.FindPropertyRelative("isLooping");
                SerializedProperty routeColor = currentRoute.FindPropertyRelative("routeColor");
                
                EditorGUILayout.PropertyField(routeName);
                EditorGUILayout.PropertyField(isLooping);
                EditorGUILayout.PropertyField(routeColor);
                
                EditorGUILayout.Space();
                EditorGUILayout.LabelField("Waypoints", EditorStyles.boldLabel);
                
                if (waypoints.arraySize > 0)
                {
                    for (int i = 0; i < waypoints.arraySize; i++)
                    {
                        EditorGUILayout.BeginHorizontal();
                        EditorGUILayout.PropertyField(waypoints.GetArrayElementAtIndex(i), 
                                                    new GUIContent("Waypoint " + i));
                        
                        if (GUILayout.Button("X", GUILayout.Width(25)))
                        {
                            // Remover waypoint
                            waypoints.DeleteArrayElementAtIndex(i);
                            break;
                        }
                        
                        EditorGUILayout.EndHorizontal();
                    }
                }
                else
                {
                    EditorGUILayout.HelpBox("Esta rota não tem waypoints.", MessageType.Info);
                }
                
                EditorGUILayout.Space();
                if (GUILayout.Button("Adicionar Waypoint na Posição do Editor"))
                {
                    // Obter posição da câmera da cena
                    SceneView sceneView = SceneView.lastActiveSceneView;
                    if (sceneView != null)
                    {
                        Vector3 position = sceneView.camera.transform.position;
                        position.y = 0; // Ajustar altura para nível do solo
                        
                        // Criar objeto para o waypoint
                        GameObject waypointObj = new GameObject("Waypoint_" + waypoints.arraySize);
                        waypointObj.transform.position = position;
                        
                        // Adicionar ao array
                        int oldSize = waypoints.arraySize;
                        waypoints.arraySize = oldSize + 1;
                        waypoints.GetArrayElementAtIndex(oldSize).objectReferenceValue = waypointObj.transform;
                    }
                }
            }
        }
        else
        {
            EditorGUILayout.HelpBox("Adicione pelo menos uma rota para configurar o piloto automático.", 
                                  MessageType.Warning);
            
            if (GUILayout.Button("Criar Rota Inicial"))
            {
                autopilot.CreateNewRoute();
                serializedObject.Update();
            }
        }
        
        // Configurações de navegação
        EditorGUILayout.Space();
        EditorGUILayout.LabelField("Configurações de Navegação", EditorStyles.boldLabel);
        EditorGUILayout.PropertyField(waypointRadius);
        EditorGUILayout.PropertyField(maxSpeed);
        EditorGUILayout.PropertyField(corneringSpeed);
        
        // Resto das propriedades
        EditorGUILayout.Space();
        EditorGUILayout.PropertyField(showDebugVisuals);
        
        // Desenhar o resto das propriedades automaticamente
        SerializedProperty prop = serializedObject.GetIterator();
        bool enterChildren = true;
        while (prop.NextVisible(enterChildren))
        {
            enterChildren = false;
            
            // Pular propriedades já mostradas
            if (prop.name == "m_Script" || prop.name == "routes" || 
                prop.name == "currentRouteIndex" || prop.name == "waypointRadius" || 
                prop.name == "maxSpeed" || prop.name == "corneringSpeed" || 
                prop.name == "showDebugVisuals")
            {
                continue;
            }
            
            EditorGUILayout.PropertyField(prop, true);
        }
        
        serializedObject.ApplyModifiedProperties();
    }
}
#endif
