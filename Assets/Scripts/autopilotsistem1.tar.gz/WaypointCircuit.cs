using UnityEngine;
using System.Collections.Generic;
using UnityEditor;


 
    [System.Serializable]
    public class Waypoint
    {
        public Vector3 position;
        public float maxSpeed = 30f; // Velocidade máxima em km/h
        public float width = 5f;     // Largura da pista neste ponto
        
        public Waypoint(Vector3 pos)
        {
            position = pos;
        }
    }

    // Classe para gerenciar o circuito de waypoints
    public class WaypointCircuit : MonoBehaviour
    {
        public Color waypointColor = Color.yellow;
        public Color connectionColor = Color.green;
        public List<Waypoint> waypoints = new List<Waypoint>();
        public bool isLooping = true;
        public float gizmoSize = 0.5f;
        
        // Proprietários para obter o waypoint mais próximo
        public int GetClosestWaypointIndex(Vector3 position)
        {
            int closestIndex = 0;
            float closestDistance = float.MaxValue;
            
            for (int i = 0; i < waypoints.Count; i++)
            {
                float distance = Vector3.Distance(position, waypoints[i].position);
                if (distance < closestDistance)
                {
                    closestDistance = distance;
                    closestIndex = i;
                }
            }
            
            return closestIndex;
        }
        
        // Método para obter o próximo waypoint
        public int GetNextWaypointIndex(int currentIndex)
        {
            int nextIndex = currentIndex + 1;
            
            if (nextIndex >= waypoints.Count)
            {
                nextIndex = isLooping ? 0 : currentIndex;
            }
            
            return nextIndex;
        }
        
        // Método para adicionar um novo waypoint na posição específica
        public void AddWaypoint(Vector3 position)
        {
            Waypoint newWaypoint = new Waypoint(position);
            waypoints.Add(newWaypoint);
        }
        
        // Método para remover um waypoint por índice
        public void RemoveWaypoint(int index)
        {
            if (index >= 0 && index < waypoints.Count)
            {
                waypoints.RemoveAt(index);
            }
        }
        
        // Método para visualização no editor
        private void OnDrawGizmos()
        {
            if (waypoints.Count == 0) return;
            
            // Desenhar os waypoints
            for (int i = 0; i < waypoints.Count; i++)
            {
                if (waypoints[i] == null) continue;
                
                Vector3 position = waypoints[i].position;
                
                // Desenhar o waypoint
                Gizmos.color = waypointColor;
                Gizmos.DrawSphere(position, gizmoSize);
                
                // Desenhar o número do waypoint
                #if UNITY_EDITOR
                Handles.Label(position + Vector3.up * gizmoSize * 2, i.ToString());
                #endif
                
                // Desenhar a conexão com o próximo waypoint
                if (isLooping || i < waypoints.Count - 1)
                {
                    int nextIndex = (i + 1) % waypoints.Count;
                    Vector3 nextPosition = waypoints[nextIndex].position;
                    
                    Gizmos.color = connectionColor;
                    Gizmos.DrawLine(position, nextPosition);
                    
                    // Desenhar seta direcional
                    Vector3 direction = (nextPosition - position).normalized;
                    Vector3 arrowPos = position + direction * Vector3.Distance(position, nextPosition) * 0.5f;
                    float arrowSize = gizmoSize * 2;
                    
                    Gizmos.DrawRay(arrowPos, Quaternion.Euler(0, 30, 0) * direction * arrowSize);
                    Gizmos.DrawRay(arrowPos, Quaternion.Euler(0, -30, 0) * direction * arrowSize);
                }
            }
        }
    
}