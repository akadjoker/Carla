
using UnityEngine;
using System.Collections.Generic;
using UnityEditor;

 
#if UNITY_EDITOR
    // Editor personalizado para WaypointCircuit para facilitar a criação de waypoints
    [CustomEditor(typeof(WaypointCircuit))]
    public class WaypointCircuitEditor : Editor
    {
        private WaypointCircuit circuit;
        private SerializedProperty waypointsProperty;
        private bool isAddingWaypoints = false;
        
        private void OnEnable()
        {
            circuit = (WaypointCircuit)target;
            waypointsProperty = serializedObject.FindProperty("waypoints");
        }
        
        public override void OnInspectorGUI()
        {
            serializedObject.Update();
            
            // Desenhar propriedades padrão
            DrawDefaultInspector();
            
            EditorGUILayout.Space();
            EditorGUILayout.HelpBox("Dica: Clique nos botões abaixo para adicionar ou remover waypoints.", MessageType.Info);
            
            EditorGUILayout.BeginHorizontal();
            
            // Botão para adicionar waypoint na posição atual
            if (GUILayout.Button("Adicionar na posição da câmera"))
            {
                Vector3 sceneViewCamera = SceneView.lastActiveSceneView.camera.transform.position;
                Undo.RecordObject(circuit, "Adicionar Waypoint");
                sceneViewCamera.y = 0;  // Definir altura no nível do chão
                circuit.AddWaypoint(sceneViewCamera);
                EditorUtility.SetDirty(circuit);
            }
            
            // Botão para habilitar/desabilitar modo de adição de waypoints
            string buttonText = isAddingWaypoints ? "Parar de adicionar" : "Adicionar com cliques";
            if (GUILayout.Button(buttonText))
            {
                isAddingWaypoints = !isAddingWaypoints;
                if (isAddingWaypoints)
                {
                    EditorGUILayout.HelpBox("Clique na cena para adicionar waypoints.", MessageType.Info);
                    SceneView.duringSceneGui += OnSceneGUI;
                }
                else
                {
                    SceneView.duringSceneGui -= OnSceneGUI;
                }
            }
            
            EditorGUILayout.EndHorizontal();
            
            // Botão para limpar todos os waypoints
            if (GUILayout.Button("Limpar todos os waypoints"))
            {
                if (EditorUtility.DisplayDialog("Confirmar", "Tem certeza que deseja remover todos os waypoints?", "Sim", "Não"))
                {
                    Undo.RecordObject(circuit, "Limpar Waypoints");
                    circuit.waypoints.Clear();
                    EditorUtility.SetDirty(circuit);
                }
            }
            
            serializedObject.ApplyModifiedProperties();
        }
        
        private void OnSceneGUI(SceneView sceneView)
        {
            if (!isAddingWaypoints) return;
            
            Event e = Event.current;
            if (e.type == EventType.MouseDown && e.button == 0)
            {
                Ray ray = HandleUtility.GUIPointToWorldRay(e.mousePosition);
                RaycastHit hit;
                if (Physics.Raycast(ray, out hit))
                {
                    Undo.RecordObject(circuit, "Adicionar Waypoint");
                    circuit.AddWaypoint(hit.point);
                    EditorUtility.SetDirty(circuit);
                    e.Use();
                }
            }
        }
    }
#endif
 
